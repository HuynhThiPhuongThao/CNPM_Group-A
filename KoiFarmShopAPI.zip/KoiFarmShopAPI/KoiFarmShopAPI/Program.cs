﻿
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(builder =>
    {
        builder.WithOrigins("http://localhost:55553")   // Cho phép tất cả các domain
               .AllowAnyHeader()  // Cho phép tất cả các header
               .AllowAnyMethod(); // Cho phép tất cả các phương thức HTTP
    });
});

// Add services to the container.


builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddHttpClient();



// Add Razor Pages service
builder.Services.AddRazorPages();

var app = builder.Build();

app.UseCors(); // Sử dụng CORS

app.UseHttpsRedirection();

app.UseAuthorization();

// C?u hình ph?c v? các file t?nh

app.UseStaticFiles();

// ??m b?o tr? v? index.html khi không tìm th?y route nào kh?p
app.MapControllers();
app.MapRazorPages();


// S? d?ng fallback ?? ph?c v? index.html cho các SPA (Single Page Application)
app.MapFallbackToFile("/index.html");

app.Run();
