﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace KoiFarmApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        // POST api/auth/register
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModel model)
        {
            if (model == null || string.IsNullOrEmpty(model.Username) || string.IsNullOrEmpty(model.Password))
            {
                return BadRequest("Invalid data.");
            }

            // Lưu thông tin người dùng vào cơ sở dữ liệu (cần thực hiện lưu vào DbContext)
            // Ví dụ này chỉ trả về phản hồi giả, bạn cần lưu vào cơ sở dữ liệu thực tế


            return Ok(new { message = "Registration successful" });
        }

        // POST api/auth/login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
            if (model == null || string.IsNullOrEmpty(model.Username) || string.IsNullOrEmpty(model.Password))
            {
                return BadRequest("Invalid data.");
            }

            // Kiểm tra đăng nhập (bạn cần kiểm tra tài khoản và mật khẩu từ cơ sở dữ liệu)

            // Ví dụ này chỉ trả về phản hồi giả, bạn cần thực hiện kiểm tra cơ sở dữ liệu thực tế

            return Ok(new { message = "Login successful" });
        }
    }

    // Model đăng ký
    public class RegisterModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    // Model đăng nhập
    public class LoginModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
