﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Services.Interfaces;

namespace KoiFarmShop.Application.Pages.CustomerManagement
{
    public class EditModel : PageModel
    {
        private readonly ICustomerService _services;

        public EditModel(ICustomerService services)
        {
            _services = services;
        }

        [BindProperty]
        public Customer Customer { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            int ID = 0;

            if (id == null)
            {
                ID = 0;
                return NotFound();
            }
            ID = (int)id;

            var customer = await _services.GetCustomerById(ID);
            if (customer == null)
            {
                return NotFound();
            }
            else
            {
                Customer = customer;
            }
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _services.UpdateCustomer(Customer);

            return RedirectToPage("./Index");
        }
    }
}
