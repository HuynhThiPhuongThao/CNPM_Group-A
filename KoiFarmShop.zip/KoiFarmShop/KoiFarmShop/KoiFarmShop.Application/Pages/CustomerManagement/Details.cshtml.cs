﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Services.Interfaces;

namespace KoiFarmShop.Application.Pages.CustomerManagement
{
    public class DetailsModel : PageModel
    {
        private readonly ICustomerService _services;

        public DetailsModel(ICustomerService services)
        {
            _services = services;
        }

        public Customer Customer { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            int ID = 0;
            if (id == null)
            {
                ID = 0;
                return NotFound();
            }
            ID = (int)id;


            var customer = await _services.GetCustomerById(ID);
            if (customer == null)
            {
                return NotFound();
            }
            else
            {
                Customer = customer;
            }
            return Page();
        }
    }
}
