﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Services.Interfaces;

namespace KoiFarmShop.Application.Pages.OrderCustomerManagement
{
    public class EditModel : PageModel
    {
        private readonly IOrderService _service;
        public EditModel(IOrderService service)
        {
            _service = service;
        }

        [BindProperty]
        public CustomerOrder CustomerOrder { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customerorder =  await _service.GetCustomerOrderById(id.Value);
            if (customerorder == null)
            {
                return NotFound();
            }
            CustomerOrder = customerorder;
            var customers = await _service.GetCustomers();
           ViewData["CustomerId"] = new SelectList(customers, "CustomerId", "CustomerId");
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                var customers = await _service.GetCustomers();
                ViewData["CustomerId"] = new SelectList(customers, "CustomerId", "CustomerId");
                return Page();
            }
            var res = _service.UpdateCustomerOrder(CustomerOrder);
            if (!res)
            {
                return NotFound();
            }

            return RedirectToPage("./Index");
        }

    }
}
