﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Services.Interfaces;

namespace KoiFarmShop.Application.Pages.OrderCustomerManagement
{
    public class DeleteModel : PageModel
    {
        private readonly IOrderService _service;

        public DeleteModel(IOrderService service)
        {
            _service = service;
        }

        [BindProperty]
        public CustomerOrder CustomerOrder { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            int Id = 0;
            if (id == null)
            {
                Id = 0;
                return NotFound();
            }
            Id =(int)id;
            var customerorder = await _service.GetCustomerOrderById(Id);

            if (customerorder == null)
            {
                return NotFound();
            }
            else
            {
                CustomerOrder = customerorder;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            
            _service.DeleteCustomerOrder((int)id);
            return RedirectToPage("./Index");
        }
    }
}
