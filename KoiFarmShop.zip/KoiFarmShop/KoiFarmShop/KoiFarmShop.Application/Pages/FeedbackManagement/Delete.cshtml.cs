﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KoiFarmShop.Repositories.Entities;

namespace KoiFarmShop.Application.Pages.FeedbackManagement
{
    public class DeleteModel : PageModel
    {
        private readonly KoiFarmShop.Repositories.Entities.KoiFarmShopContext _context;

        public DeleteModel(KoiFarmShop.Repositories.Entities.KoiFarmShopContext context)
        {
            _context = context;
        }

        [BindProperty]
        public CustomerFeedback CustomerFeedback { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customerfeedback = await _context.CustomerFeedbacks.FirstOrDefaultAsync(m => m.FeedbackId == id);

            if (customerfeedback == null)
            {
                return NotFound();
            }
            else
            {
                CustomerFeedback = customerfeedback;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customerfeedback = await _context.CustomerFeedbacks.FindAsync(id);
            if (customerfeedback != null)
            {
                CustomerFeedback = customerfeedback;
                _context.CustomerFeedbacks.Remove(CustomerFeedback);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
