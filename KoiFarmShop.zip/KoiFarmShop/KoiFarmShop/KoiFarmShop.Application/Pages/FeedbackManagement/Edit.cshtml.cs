﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KoiFarmShop.Repositories.Entities;

namespace KoiFarmShop.Application.Pages.FeedbackManagement
{
    public class EditModel : PageModel
    {
        private readonly KoiFarmShop.Repositories.Entities.KoiFarmShopContext _context;

        public EditModel(KoiFarmShop.Repositories.Entities.KoiFarmShopContext context)
        {
            _context = context;
        }

        [BindProperty]
        public CustomerFeedback CustomerFeedback { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customerfeedback =  await _context.CustomerFeedbacks.FirstOrDefaultAsync(m => m.FeedbackId == id);
            if (customerfeedback == null)
            {
                return NotFound();
            }
            CustomerFeedback = customerfeedback;
           ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "CustomerId");
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(CustomerFeedback).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerFeedbackExists(CustomerFeedback.FeedbackId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool CustomerFeedbackExists(int id)
        {
            return _context.CustomerFeedbacks.Any(e => e.FeedbackId == id);
        }
    }
}
