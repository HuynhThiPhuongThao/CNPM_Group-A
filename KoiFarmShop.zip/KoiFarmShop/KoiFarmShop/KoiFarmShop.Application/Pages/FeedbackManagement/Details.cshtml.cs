﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KoiFarmShop.Repositories.Entities;

namespace KoiFarmShop.Application.Pages.FeedbackManagement
{
    public class DetailsModel : PageModel
    {
        private readonly KoiFarmShop.Repositories.Entities.KoiFarmShopContext _context;

        public DetailsModel(KoiFarmShop.Repositories.Entities.KoiFarmShopContext context)
        {
            _context = context;
        }

        public CustomerFeedback CustomerFeedback { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customerfeedback = await _context.CustomerFeedbacks.FirstOrDefaultAsync(m => m.FeedbackId == id);
            if (customerfeedback == null)
            {
                return NotFound();
            }
            else
            {
                CustomerFeedback = customerfeedback;
            }
            return Page();
        }
    }
}
