﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KoiFarmShop.Repositories.Entities;

namespace KoiFarmShop.Application.Pages.FeedbackManagement
{
    public class IndexModel : PageModel
    {
        private readonly KoiFarmShop.Repositories.Entities.KoiFarmShopContext _context;

        public IndexModel(KoiFarmShop.Repositories.Entities.KoiFarmShopContext context)
        {
            _context = context;
        }

        public IList<CustomerFeedback> CustomerFeedback { get;set; } = default!;

        public async Task OnGetAsync()
        {
            CustomerFeedback = await _context.CustomerFeedbacks
                .Include(c => c.Customer).ToListAsync();
        }
    }
}
