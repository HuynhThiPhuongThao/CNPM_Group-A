﻿using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Repositories.Interfaces;
using KoiFarmShop.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _repository;
        public CustomerService(ICustomerRepository repository)
        {
            _repository = repository;
        }

        public bool AddCustomer(Customer customer)
        {
            return _repository.AddCustomer(customer);
        }

        public Task<List<Customer>> Customers()
        {
            return _repository.GetAllCustomers();
            
        }

        public bool DeleteCustomer(Customer customer)
        {
            return _repository.DeleteCustomer(customer);
        }

        public bool DeleteCustomer(int ID)
        {
            return (_repository.DeleteCustomer(ID));
        }

        public Task<List<Customer>> GetAllCustomersAsync()
        {
            return _repository.GetAllCustomers();
        }

        public Task<Customer> GetCustomerById(int ID)
        {
            return _repository.GetCustomerById(ID);
        }

        public bool UpdateCustomer(Customer customer)
        {
            return _repository.UpdateCustomer(customer);
        }
    }
}
