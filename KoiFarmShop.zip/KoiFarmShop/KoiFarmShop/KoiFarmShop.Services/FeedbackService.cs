﻿using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Repositories.Interfaces;
using KoiFarmShop.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Services
{
    public class FeedbackService: IFeedbackService
    {
        private readonly IFeedbackRepository _repository;
        public FeedbackService(IFeedbackRepository repository)
        {
            _repository = repository;
        }

        public bool AddFeedback(CustomerFeedback feedback)
        {
            return _repository.AddFeedback(feedback);
        }

        public bool DeleteFeedback(CustomerFeedback feedback)
        {
            return _repository.DeleteFeedback(feedback);
        }

        public bool DeleteFeedback(int ID)
        {
            return (_repository.DeleteFeedback(ID));
        }

        public Task<List<CustomerFeedback>> Feedbacks()
        {
            return _repository.GetAllFeedbacks();
        }

        public Task<CustomerFeedback> GetFeedbackById(int ID)
        {
            return _repository.GetFeedbackById(ID);
        }

        public bool UpdateFeedback(CustomerFeedback feedback)
        {
           return _repository.UpdateFeedback(feedback);
        }
    }
}
