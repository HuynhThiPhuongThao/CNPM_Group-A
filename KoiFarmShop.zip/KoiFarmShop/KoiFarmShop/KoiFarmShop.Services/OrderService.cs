﻿using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Repositories.Interfaces;
using KoiFarmShop.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Services
{
    public class OrderService : IOrderService 
    {
        private readonly IOrderRepository _repository;
        private readonly ICustomerService _service;

        public OrderService(IOrderRepository repository, ICustomerService service)
        {
            _repository = repository;
            _service = service;
        }
        public bool AddCustomerOrder(CustomerOrder customerOrder)
        {
            return _repository.AddCustomerOrder(customerOrder);
        }

        public bool DeleteCustomerOrder(CustomerOrder customerOrder)
        {
            return _repository.DeleteCustomerOrder(customerOrder);
        }

        public bool DeleteCustomerOrder(int id)
        {
            return _repository.DeleteCustomerOrder(id);
        }

        public Task<CustomerOrder> GetCustomerOrderById(int id)
        {
            return _repository.GetCustomerOrderById(id);
        }

        public async Task<IEnumerable<Customer>> GetCustomers()
        {
            var customers = await _service.GetAllCustomersAsync();
            return customers;
        }

        public Task<List<CustomerOrder>> Orders()
        {
            return _repository.GetAllCustomerOrders();
        }

        public bool UpdateCustomerOrder(CustomerOrder customerOrder)
        {
            return _repository.UpdateCustomerOrder(customerOrder);
        }
    }
}
