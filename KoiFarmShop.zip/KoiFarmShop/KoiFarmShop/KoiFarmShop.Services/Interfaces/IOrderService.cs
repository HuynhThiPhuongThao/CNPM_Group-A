﻿using KoiFarmShop.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Services.Interfaces
{
    public interface IOrderService
    {
        Task<List<CustomerOrder>> Orders();
        Boolean AddCustomerOrder(CustomerOrder customerOrder);
        Boolean DeleteCustomerOrder(CustomerOrder customerOrder);
        Boolean DeleteCustomerOrder(int id);
        Boolean UpdateCustomerOrder(CustomerOrder customerOrder);
        Task<CustomerOrder> GetCustomerOrderById(int id);
        Task<IEnumerable<Customer>> GetCustomers();

    }
}
