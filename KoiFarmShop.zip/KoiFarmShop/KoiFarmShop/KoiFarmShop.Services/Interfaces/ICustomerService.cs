﻿using KoiFarmShop.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Services.Interfaces
{
    public interface ICustomerService
    {
        Task<List<Customer>> Customers();
        Boolean AddCustomer(Customer customer);
        Boolean UpdateCustomer(Customer customer);
        Boolean DeleteCustomer(Customer customer);
        Boolean DeleteCustomer(int ID);
        Task<Customer> GetCustomerById(int ID);
        Task<List<Customer>> GetAllCustomersAsync();

    }
}
