﻿using KoiFarmShop.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Services.Interfaces
{
    public interface IFeedbackService
    {
        Task<List<CustomerFeedback>> Feedbacks();
        Boolean AddFeedback(CustomerFeedback  feedback);
        Boolean UpdateFeedback(CustomerFeedback feedback);
        Boolean DeleteFeedback(CustomerFeedback feedback);
        Boolean DeleteFeedback(int ID);
        Task<CustomerFeedback> GetFeedbackById(int ID);

    }
}
