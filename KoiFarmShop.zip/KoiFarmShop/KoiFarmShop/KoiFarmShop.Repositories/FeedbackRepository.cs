﻿using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Repositories
{
    public class FeedbackRepository : IFeedbackRepository
    {
        private readonly KoiFarmShopContext _context;
        public FeedbackRepository(KoiFarmShopContext context)
        {
            _context = context;
        }
        public bool AddFeedback(CustomerFeedback feedback)
        {
            try
            {
                _context.CustomerFeedbacks.Add(feedback);
                _context.SaveChanges();
                return true;

            }
            catch (Exception ex)
            {
                throw new NotImplementedException();
            }
        }

        public bool DeleteFeedback(CustomerFeedback feedback)
        {
            try
            {
                _context.Remove(feedback);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw new NotImplementedException(ex.ToString());
                return false;
            }
        }

        public bool DeleteFeedback(int ID)
        {
            try
            {
                var feedback = _context.CustomerFeedbacks.Where(p => p.CustomerId.Equals(ID)).FirstOrDefault();
                if (feedback != null)
                {
                    _context.CustomerFeedbacks.Remove(feedback);
                    _context.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new NotImplementedException(ex.ToString());
            }
        }

        public async Task<List<CustomerFeedback>> GetAllFeedbacks()
        {
            return await _context.CustomerFeedbacks.ToListAsync();
        }

        public async Task<CustomerFeedback> GetFeedbackById(int ID)
        {
            return await _context.CustomerFeedbacks.Where(p => p.FeedbackId.Equals(ID)).FirstOrDefaultAsync();
        }

        public bool UpdateFeedback(CustomerFeedback feedback)
        {
            try
            {
                _context.CustomerFeedbacks.Update(feedback);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
