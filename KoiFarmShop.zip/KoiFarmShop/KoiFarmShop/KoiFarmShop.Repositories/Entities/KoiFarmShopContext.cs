﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace KoiFarmShop.Repositories.Entities;

public partial class KoiFarmShopContext : DbContext
{
    public KoiFarmShopContext()
    {
    }

    public KoiFarmShopContext(DbContextOptions<KoiFarmShopContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<CustomerFeedback> CustomerFeedbacks { get; set; }

    public virtual DbSet<CustomerOrder> CustomerOrders { get; set; }

    public virtual DbSet<DashboardReport> DashboardReports { get; set; }

    public virtual DbSet<Deposit> Deposits { get; set; }

    public virtual DbSet<Fish> Fish { get; set; }

    public virtual DbSet<FishComparison> FishComparisons { get; set; }

    public virtual DbSet<OrderDetail> OrderDetails { get; set; }

    public virtual DbSet<Promotion> Promotions { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=LAPTOP-GVK656O0\\SQLEXPRESS;Initial Catalog=KoiFarmShop;Integrated Security=True;Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.CustomerId).HasName("PK__Customer__A4AE64D8FA759E1F");

            entity.ToTable("Customer");

            entity.Property(e => e.Address).HasMaxLength(255);
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Phone).HasMaxLength(20);
        });

        modelBuilder.Entity<CustomerFeedback>(entity =>
        {
            entity.HasKey(e => e.FeedbackId).HasName("PK__Customer__6A4BEDD607B28C03");

            entity.ToTable("CustomerFeedback");

            entity.Property(e => e.Comment).HasMaxLength(255);
            entity.Property(e => e.FeedbackDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Customer).WithMany(p => p.CustomerFeedbacks)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("FK__CustomerF__Custo__4BAC3F29");
        });

        modelBuilder.Entity<CustomerOrder>(entity =>
        {
            entity.HasKey(e => e.OrderId).HasName("PK__Customer__C3905BCFCD93909C");

            entity.ToTable("CustomerOrder");

            entity.Property(e => e.OrderDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.Property(e => e.TotalAmount).HasColumnType("decimal(10, 2)");

            entity.HasOne(d => d.Customer).WithMany(p => p.CustomerOrders)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("FK__CustomerO__Custo__3D5E1FD2");
        });

        modelBuilder.Entity<DashboardReport>(entity =>
        {
            entity.HasKey(e => e.ReportId).HasName("PK__Dashboar__D5BD4805B3E80376");

            entity.ToTable("DashboardReport");

            entity.Property(e => e.ReportDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.TotalSales).HasColumnType("decimal(10, 2)");
        });

        modelBuilder.Entity<Deposit>(entity =>
        {
            entity.HasKey(e => e.DepositId).HasName("PK__Deposit__AB60DF711FFEB377");

            entity.ToTable("Deposit");

            entity.Property(e => e.DepositDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Status).HasMaxLength(50);

            entity.HasOne(d => d.Customer).WithMany(p => p.Deposits)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("FK__Deposit__Custome__44FF419A");

            entity.HasOne(d => d.Fish).WithMany(p => p.Deposits)
                .HasForeignKey(d => d.FishId)
                .HasConstraintName("FK__Deposit__FishId__45F365D3");
        });

        modelBuilder.Entity<Fish>(entity =>
        {
            entity.HasKey(e => e.FishId).HasName("PK__Fish__F82A5BD99EC38DD5");

            entity.Property(e => e.AwardCertificates).HasMaxLength(255);
            entity.Property(e => e.Breed).HasMaxLength(50);
            entity.Property(e => e.Characteristics).HasMaxLength(255);
            entity.Property(e => e.FeedAmount).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.FilterRate).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Origin).HasMaxLength(100);
            entity.Property(e => e.Price).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Size).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Status).HasMaxLength(50);
        });

        modelBuilder.Entity<FishComparison>(entity =>
        {
            entity.HasKey(e => e.ComparisonId).HasName("PK__FishComp__6E1F995748F88CF1");

            entity.ToTable("FishComparison");

            entity.Property(e => e.Differences).HasMaxLength(255);
            entity.Property(e => e.Similarities).HasMaxLength(255);

            entity.HasOne(d => d.FishId1Navigation).WithMany(p => p.FishComparisonFishId1Navigations)
                .HasForeignKey(d => d.FishId1)
                .HasConstraintName("FK__FishCompa__FishI__5165187F");

            entity.HasOne(d => d.FishId2Navigation).WithMany(p => p.FishComparisonFishId2Navigations)
                .HasForeignKey(d => d.FishId2)
                .HasConstraintName("FK__FishCompa__FishI__52593CB8");
        });

        modelBuilder.Entity<OrderDetail>(entity =>
        {
            entity.HasKey(e => e.OrderDetailId).HasName("PK__OrderDet__D3B9D36CFA15609A");

            entity.Property(e => e.Price).HasColumnType("decimal(10, 2)");

            entity.HasOne(d => d.Fish).WithMany(p => p.OrderDetails)
                .HasForeignKey(d => d.FishId)
                .HasConstraintName("FK__OrderDeta__FishI__412EB0B6");

            entity.HasOne(d => d.Order).WithMany(p => p.OrderDetails)
                .HasForeignKey(d => d.OrderId)
                .HasConstraintName("FK__OrderDeta__Order__403A8C7D");
        });

        modelBuilder.Entity<Promotion>(entity =>
        {
            entity.HasKey(e => e.PromotionId).HasName("PK__Promotio__52C42FCF026110CA");

            entity.ToTable("Promotion");

            entity.Property(e => e.Code).HasMaxLength(50);
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.Discount).HasColumnType("decimal(5, 2)");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
