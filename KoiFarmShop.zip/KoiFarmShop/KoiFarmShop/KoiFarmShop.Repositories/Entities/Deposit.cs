﻿using System;
using System.Collections.Generic;

namespace KoiFarmShop.Repositories.Entities;

public partial class Deposit
{
    public int DepositId { get; set; }

    public int? CustomerId { get; set; }

    public int? FishId { get; set; }

    public DateTime? DepositDate { get; set; }

    public bool? IsOffline { get; set; }

    public string? Status { get; set; }

    public virtual Customer? Customer { get; set; }

    public virtual Fish? Fish { get; set; }
}
