﻿using System;
using System.Collections.Generic;

namespace KoiFarmShop.Repositories.Entities;

public partial class FishComparison
{
    public int ComparisonId { get; set; }

    public int? FishId1 { get; set; }

    public int? FishId2 { get; set; }

    public string? Similarities { get; set; }

    public string? Differences { get; set; }

    public virtual Fish? FishId1Navigation { get; set; }

    public virtual Fish? FishId2Navigation { get; set; }
}
