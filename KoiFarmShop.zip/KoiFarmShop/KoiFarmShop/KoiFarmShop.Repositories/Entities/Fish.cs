﻿using System;
using System.Collections.Generic;

namespace KoiFarmShop.Repositories.Entities;

public partial class Fish
{
    public int FishId { get; set; }

    public string Name { get; set; } = null!;

    public string? Breed { get; set; }

    public decimal? Size { get; set; }

    public int? Age { get; set; }

    public string? Origin { get; set; }

    public string? Characteristics { get; set; }

    public decimal? FeedAmount { get; set; }

    public decimal? FilterRate { get; set; }

    public decimal? Price { get; set; }

    public string? Status { get; set; }

    public string? AwardCertificates { get; set; }

    public virtual ICollection<Deposit> Deposits { get; set; } = new List<Deposit>();

    public virtual ICollection<FishComparison> FishComparisonFishId1Navigations { get; set; } = new List<FishComparison>();

    public virtual ICollection<FishComparison> FishComparisonFishId2Navigations { get; set; } = new List<FishComparison>();

    public virtual ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
}
