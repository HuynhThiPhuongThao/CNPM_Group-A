﻿using KoiFarmShop.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Repositories.Interfaces
{
    public interface IOrderRepository
    {
        Task<List<CustomerOrder>> GetAllCustomerOrders();
        Boolean AddCustomerOrder(CustomerOrder customerOrder);
        Boolean DeleteCustomerOrder(CustomerOrder customerOrder);
        Boolean DeleteCustomerOrder(int id);
        Boolean UpdateCustomerOrder(CustomerOrder customerOrder);
        Task<CustomerOrder> GetCustomerOrderById(int id);
        

    }
}
