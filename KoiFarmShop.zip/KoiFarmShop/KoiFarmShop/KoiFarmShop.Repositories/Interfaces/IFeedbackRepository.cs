﻿using KoiFarmShop.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Repositories.Interfaces
{
    public interface IFeedbackRepository
    {
        Task<List<CustomerFeedback>> GetAllFeedbacks();
        Boolean AddFeedback(CustomerFeedback customer);
        Boolean UpdateFeedback(CustomerFeedback customer);
        Boolean DeleteFeedback(CustomerFeedback customer);
        Boolean DeleteFeedback(int ID);
        Task<CustomerFeedback> GetFeedbackById(int ID);
    }
}
