﻿using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
            private readonly KoiFarmShopContext _context;
        public CustomerRepository(KoiFarmShopContext context)
        {
            _context = context;
        }

        public bool AddCustomer(Customer customer)
        {
            try
            {
                _context.Customers.Add(customer);
                _context.SaveChanges();
                return true;

            }
            catch (Exception ex)
            {
                throw new NotImplementedException();
            }
        }

        public bool DeleteCustomer(Customer customer)
        {
            try
            {
                _context.Remove(customer);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw new NotImplementedException(ex.ToString());
                return false;
            }
        }

        public bool DeleteCustomer(int ID)
        {
            try
            {
                var customer = _context.Customers.Where(p => p.CustomerId.Equals(ID)).FirstOrDefault();
                if (customer != null)
                {
                    _context.Customers.Remove(customer);
                    _context.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new NotImplementedException(ex.ToString());
            }

        }

        public async Task<List<Customer>> GetAllCustomers()
        {
            return await _context.Customers.ToListAsync();
        }

        public async Task<Customer> GetCustomerById(int ID)
        {
            return await _context.Customers.Where(p => p.CustomerId.Equals(ID)).FirstOrDefaultAsync();
        }

        public bool UpdateCustomer(Customer customer)
        {
            try
            {
                _context.Customers.Update(customer);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}


