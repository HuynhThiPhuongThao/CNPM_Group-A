﻿using KoiFarmShop.Repositories.Entities;
using KoiFarmShop.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoiFarmShop.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly KoiFarmShopContext _context;
        public OrderRepository(KoiFarmShopContext context) 
        {
            _context = context;
        }

        public bool AddCustomerOrder(CustomerOrder customerOrder)
        {
            try
            {
                _context.CustomerOrders.Add(customerOrder);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex) {
                throw new NotImplementedException();
            }
        }

        public bool DeleteCustomerOrder(CustomerOrder customerOrder)
        {
            try
            {
                _context.Remove(customerOrder);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw new NotImplementedException(ex.ToString());
            }
        }

        public bool DeleteCustomerOrder(int id)
        {
            try
            {
                var order = _context.CustomerOrders.Where(p => p.OrderId.Equals(id)).FirstOrDefault();
                if (order != null)
                {
                    _context.CustomerOrders.Remove(order);
                    _context.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new NotImplementedException(ex.ToString());
            }
        }

        public async Task<List<CustomerOrder>> GetAllCustomerOrders()
        {
            return await _context.CustomerOrders.ToListAsync();
        }

        public async Task<CustomerOrder> GetCustomerOrderById(int id)
        {
            return await _context.CustomerOrders.Where(p => p.OrderId.Equals(id)).FirstOrDefaultAsync();
        }

        public bool UpdateCustomerOrder(CustomerOrder customerOrder)
        {
            try
            {
                _context.CustomerOrders.Update(customerOrder);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
